#include <iostream>

using namespace std;

int main()
{
    int examscore;

    cout<<"please enter your exam score,"<<endl;
    cin>> examscore;
    switch(examscore){
        case 0 ... 39:
        cout<<"FAIL"<<endl;
        break;
        case 40 ... 49:
        cout<<"FAIL RE-EXAM ALLOWED"<<endl;
        break;
        case 50 ... 64:
        cout<<"PASS"<<endl;
        break;
        case 65 ... 74:
        cout<<"PASS WITH MERIT"<<endl;
        break;
        case 75 ... 100:
        cout<<"PASS WITH DISTINCTION"<<endl;
        break;
        default:
            cout<<"ERROR INVALID_EXAM_SCORE"<<endl;
    }
    return 0;
}
