-- Create a new table
CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    department VARCHAR(50),
    salary DECIMAL(10, 2)
);

-- Insert initial data into the table
INSERT INTO employees (employee_id, first_name, last_name, department, salary)
VALUES
    (1, 'John', 'Doe', 'HR', 50000.00),
    (2, 'Alice', 'Smith', 'Finance', 60000.00),
    (3, 'Bob', 'Johnson', 'IT', 55000.00);

-- Update Alice's salary
UPDATE employees
SET salary = 62000.00
WHERE first_name = 'Alice' AND last_name = 'Smith';

-- Retrieve data from the table
SELECT * FROM employees;