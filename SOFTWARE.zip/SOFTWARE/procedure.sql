202106158 Kalane Lindelani


CREATE OR REPLACE PROCEDURE get_product_description(
    p_product_type IN VARCHAR2,
    p_description OUT VARCHAR2
)
IS
BEGIN
    -- Check the input value and assign the corresponding description
    CASE UPPER(p_product_type)
        WHEN 'C' THEN
            p_description := 'Coffee';
        WHEN 'E' THEN
            p_description := 'Equipment';
        ELSE
            -- Handle other cases if needed, for example, raise an exception
            RAISE_APPLICATION_ERROR(-20001, 'Invalid product type: ' || p_product_type);
    END CASE;
END;
/