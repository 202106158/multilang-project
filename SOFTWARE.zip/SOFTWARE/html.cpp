<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Greeting</title>
</head>
<body>

<script>
// Function to prompt the user for their name
function promptForName() {
    return new Promise((resolve, reject) => {
        const name = prompt("What's your name?");
        if (name) {
            resolve(name);
        } else {
            reject(new Error("No name provided"));
        }
    });
}

// Function to display a personalized greeting
async function displayGreeting() {
    try {
        const name = await promptForName();
        alert(`Hello, ${name}! Welcome to our website.`);
    } catch (error) {
        console.error("Error:", error.message);
    }
}

// Call the displayGreeting function to prompt the user and display the greeting
displayGreeting();
</script>

</body>
</html>