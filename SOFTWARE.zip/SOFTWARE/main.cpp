#include <iostream>

using namespace std;

int main()
{
    double bankBalance;
    cout<<"enter your bank balance"<<endl;
    cin>>bankBalance;
    cout<<"your bank balance is ZAR200.00"<<endl;
    return 0;
}
;
