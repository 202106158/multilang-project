#include <iostream> 
using namespace std;

int main()
{
    double firstValue, secondValue;

    cout<<"Please enter first value";
    cin>>firstValue;
    cout<<"Please enter second value";
    cin>>secondValue;

    if (firstValue>secondValue)
        cout<<"The first number you entered is larger"<<endl;
    else
        if (firstValue<secondValue)
        cout<<"The second number you entered is larger";
    else
        cout<<"The number are equal";
    return 0;
}