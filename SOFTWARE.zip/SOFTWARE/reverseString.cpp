#include <iostream>

using namespace std;

void revString(string& name,int n,int i)
{
    if(n<=i){return;}
    swap(name[i],name[n]);
    revString(name,n-1,i+1);
}

int main() {
    string name;
    cout<<"Enter a name"<<endl;
    cin>>name;
    revString(name,name.length()-1,0);
    cout<<"reversed string name is:"<<name<<endl;
    return 0;

}