202106158 KALANE LINDELANI

DECLARE
   -- Declare an exception variable
   custom_exception EXCEPTION;
   PRAGMA EXCEPTION_INIT(custom_exception, -2292); -- Constraint violation error code
   
BEGIN
   -- Attempt to update the bb_basketitem table
   UPDATE bb_basketitem
   SET idbasket = 99
   WHERE idbasketitem = 38;
   
   -- Display success message if update is successful
   DBMS_OUTPUT.PUT_LINE('Update successful.');
   
EXCEPTION
   -- Handle the exception if it occurs
   WHEN custom_exception THEN
      -- Display a brief message indicating the nature of the error
      DBMS_OUTPUT.PUT_LINE('Error: Constraint violation. Cannot update idbasket.');
   
   WHEN OTHERS THEN
      -- Handle any other exceptions
      DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END;
