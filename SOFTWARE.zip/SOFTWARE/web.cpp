<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Greeting</title>
</head>
<body>

<h1>Welcome</h1>

<form id="greetingForm">
    <label for="name">Enter your name:</label><br>
    <input type="text" id="name" name="name"><br>
    <button type="submit">Submit</button>
</form>

<div id="greetingMessage"></div>

<script>
// Function to handle form submission
function handleFormSubmit(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get the value of the input field
    const nameInput = document.getElementById("name");
    const name = nameInput.value.trim();

    // Display the personalized greeting
    const greetingMessage = document.getElementById("greetingMessage");
    greetingMessage.textContent = `Hello, ${name}! Welcome to our website.`;
}

// Add event listener for form submission
const greetingForm = document.getElementById("greetingForm");
greetingForm.addEventListener("submit", handleFormSubmit);
</script>

</body>
</html>