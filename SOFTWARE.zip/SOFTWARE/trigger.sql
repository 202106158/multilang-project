CREATE OR REPLACE TRIGGER BB_ORDCANCEL_TRG
AFTER INSERT ON BB_BASKETSTATUS
FOR EACH ROW
WHEN (NEW.IDSTAGE = 4)
DECLARE
    v_basket_id BB_BASKET.IDBASKET%TYPE;
    v_product_id BB_BASKETITEM.IDPRODUCT%TYPE;
    v_quantity NUMBER;
BEGIN
    -- Get the basket ID
    SELECT idBasket INTO v_basket_id FROM BB_BASKET WHERE idBasket = :NEW.idBasket;
    
    -- Loop through basket items
    FOR basket_item IN (SELECT IDPRODUCT, QUANTITY FROM BB_BASKETITEM WHERE idBasket = v_basket_id)
    LOOP
        v_product_id := basket_item.IDPRODUCT;
        v_quantity := basket_item.QUANTITY;
        
        -- Update stock levels based on quantity and product type (coffee in half or whole pounds)
        IF v_quantity >= 1 THEN
            UPDATE BB_PRODUCT
            SET STOCK = STOCK + v_quantity
            WHERE IDPRODUCT = v_product_id;
        ELSE
            UPDATE BB_PRODUCT
            SET STOCK= STOCK + (v_quantity * 0.5)
            WHERE IDPRODUCT = v_product_id;
        END IF;
    END LOOP;
    
    -- Update ORDERPLACED column of BB_BASKET to zero
    UPDATE BB_BASKET
    SET ORDERPLACED = 0
    WHERE idBasket = v_basket_id;
END;
INSERT INTO bb_basketstatus (idStatus, idBasket, idStage, dtStage)
VALUES (bb_status_seq.NEXTVAL, 6, 4, SYSDATE);
SELECT * FROM BB_BASKET WHERE idbasket = 6;
SELECT * FROM BB_PRODUCT;