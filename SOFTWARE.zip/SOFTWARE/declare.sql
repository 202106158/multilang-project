202106158 Kalane Lindelani


DECLARE
    v_product_type VARCHAR2(1) := 'C'; -- Example value (C for Coffee)
    v_description VARCHAR2(50); -- Output parameter for the description

BEGIN
    get_product_description(p_product_type => v_product_type, p_description => v_description);

    -- Display the result
    DBMS_OUTPUT.PUT_LINE('Product Type: ' || v_product_type);
    DBMS_OUTPUT.PUT_LINE('Product Description: ' || v_description);
END;
/