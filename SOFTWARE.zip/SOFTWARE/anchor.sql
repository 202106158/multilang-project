kALANE LINDELANI 202106158



DECLARE
    project_id dd_project.idproj%TYPE :=  502;
    project_name dd_project.projname%TYPE;
    num_pledges NUMBER(9,3);
    total_pledged dd_payment.payamt%TYPE;
    avg_pledge NUMBER(9,3);
BEGIN
    SELECT projname
    INTO project_name
    FROM dd_project
    WHERE idproj = project_id;

        SELECT COUNT(*) AS pledgeamt, 
           NVL(SUM(pledgeamt), 0) AS total_pledged,
           NVL(SUM(pledgeamt) / NULLIF(COUNT(*), 0), 0) AS avg_pledge
    INTO num_pledges, total_pledged, avg_pledge
    FROM dd_pledge
    WHERE idproj = project_id;

    
    DBMS_OUTPUT.PUT_LINE('Project ID: ' || project_id);
    DBMS_OUTPUT.PUT_LINE('Project Name: ' || project_name);
    DBMS_OUTPUT.PUT_LINE('Number of Pledges: ' || num_pledges);
    DBMS_OUTPUT.PUT_LINE('Total Dollars Pledged: $' || TO_CHAR(total_pledged, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('Average Pledge Amount: $' || TO_CHAR(avg_pledge, '999,999,99'));
END;
/