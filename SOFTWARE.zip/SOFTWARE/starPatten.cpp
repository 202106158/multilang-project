#include <iostream>

using namespace std;

void starPattern()
{
    int rows;
    cout<<"enter the number of rows "<<endl;
    cin>>rows;
    for(int i= 1; i <= rows; ++i)
    {
        for(int j = 1; j<=i; ++j)
        {
            cout<<"* ";
        }
    cout<<"\n";
    }

}
int main() {

    starPattern();
    return 0;

}
